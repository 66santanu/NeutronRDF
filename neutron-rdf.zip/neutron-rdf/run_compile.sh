gfortran src/rdf.f90 -o bin/rdf
